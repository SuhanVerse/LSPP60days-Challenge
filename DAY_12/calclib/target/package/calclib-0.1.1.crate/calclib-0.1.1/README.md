# calclib

A simple Rust math library.

## Quick Start

Add to your `Cargo.toml`:

```toml
# plain usage
calclib = "0.1.1"

# with fancy output
calclib = { version = "0.1.1", features = ["fancy"] }
